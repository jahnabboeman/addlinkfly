<?php

namespace App\Controller\Admin;

use App\Controller\Member\AppAdminController;

class CampaignCountriesController extends AppAdminController
{
}
